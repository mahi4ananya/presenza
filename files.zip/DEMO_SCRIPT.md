# Presenza — Demo Video Script & Storyboard

**Target length: ~2:14 (134 seconds).** The prototype now has a **"Play full
demo" button** in the toolbar that runs this exact sequence automatically —
switching roles and tabs, triggering the punch-in flow, sending chat
messages, and simulating live punch-ins — with on-screen captions synced to
each beat and a progress bar so you know where you are.

## Fastest path to a finished video

1. Open `presenza-prototype`, zoom your browser to ~110–125% so the phone
   fills the frame nicely.
2. Start your screen recorder.
3. Click **"Play full demo."** Don't touch anything else — just let it run
   (134 seconds) and stop your recording a couple seconds after it ends.
4. That's a complete, captioned walkthrough of all five features. Optional:
   read the voiceover lines below out loud while it plays, or add them as
   captions/voiceover afterward in your video editor — the on-screen caption
   bar already shows the same lines as subtitles, so it works silently too.

The manual, section-by-section version below is for reference if you'd
rather record it by hand, or want a different pace.

---

### 0:00–0:15 — Cold open (problem)
**Screen:** Title card or the pitch deck's slide 2 ("Campus Attendance Is
Still Manual, Fakeable & Disconnected").
**VO:** "Proxy attendance. No real-time visibility. Class updates lost in a
WhatsApp group. And a Class Rep stuck being the unpaid middleman. That's
campus attendance today. We built Presenza to fix it."

### 0:15–0:30 — Introduce the product
**Screen:** Prototype loads, Student view, role switch visible at top.
**VO:** "Presenza is a single portal that verifies real attendance, tracks
every student's standing in real time, and connects students and teachers
directly — no middleman."

### 0:30–1:05 — Feature 1: Smart Punch-In + Anti-Proxy Lock
**Screen:** Student → Punch In tab. Tap "Punch in now." Let the three checks
play out on screen (device binding → GPS → session window) to the success
state.
**VO:** "Here's a live Thermodynamics session. The student taps punch in —
and behind that single tap, three checks run automatically: the app confirms
this is their registered device, confirms they're physically inside the
classroom via live GPS, and confirms the session window is still open. Only
then are they marked present. That's what makes proxy attendance — someone
else marking you present from home — impossible."
**Action:** Click "Reset demo" to show it can run again live.

### 1:05–1:35 — Feature 2: 75% Tracker
**Screen:** Switch to Tracker tab. Point out the ring and subject list.
**VO:** "Every student sees exactly where they stand — an overall attendance
ring, and a subject-by-subject breakdown. Most colleges require 75%
attendance to sit for exams, but students usually find out too late. Here,
Presenza tells them precisely: attend six more Thermodynamics lectures to
move from Average to Good — before it becomes a crisis."

### 1:35–2:00 — Feature 3: Teacher ↔ Student Chat
**Screen:** Student → Chat tab, show existing messages, then send one.
**VO:** "And when a class is cancelled or moved, there's no more waiting on
a WhatsApp forward. Teachers message the whole batch — or a single student —
directly inside the app."

### 2:00–2:35 — Switch to Teacher view: Rating Engine + Session + Roster
**Screen:** Toggle to Teacher view. Show Ratings tab (change a "lectures
planned" number, watch thresholds recompute). Then Session tab (start
session, tap "Simulate a student punch-in" a couple times to show the live
feed). Then Roster tab (pie chart + at-risk list).
**VO:** "On the teacher side, it's just as simple. Set how many lectures are
planned for a topic, and Presenza calculates the Excellent/Good/Average/Poor
thresholds automatically. Start a session and watch punch-ins arrive live,
geo-verified. And at a glance, teachers and administrators see the whole
class's attendance health — with students at risk flagged automatically,
no manual spreadsheet required."

### 2:35–2:55 — Close
**Screen:** Return to Student Tracker or the "Thank You" deck slide.
**VO:** "One portal. Verified attendance. Direct communication. Zero
middlemen. That's Presenza."
**On-screen text:** "Presenza — HackHers · CodeBuild 1.0 Hackathon 2026"

---

## Recording tips
- Record at 1080p, prototype browser window sized so the phone frame is
  large and centered (zoom your browser to ~110–125% first).
- If using "Play full demo," don't click anything else mid-run — manual taps
  are disabled automatically while it's playing, but switching browser tabs
  can throttle the timers, so keep the tab focused and visible.
- "Stop demo" cancels the run cleanly at any point if you need a retake.
- The on-screen caption bar doubles as burned-in subtitles, so the video is
  understandable even muted — great for judges skimming submissions fast.
- Want narration instead of the captions? Mute the caption text visually by
  cropping it out in your editor, and read the matching VO lines above in
  sync with the progress bar timestamps (each step's `delay` in the code is
  its start time in milliseconds).
