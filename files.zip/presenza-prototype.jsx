import React, { useState, useEffect, useRef } from "react";
import {
  Home, MessageCircle, Users, CheckCircle2, MapPin, Smartphone,
  ShieldCheck, Bell, Send, Radio, Lock, GraduationCap, Building2,
  TrendingUp, AlertTriangle, Clock, BookOpen, Play, Square,
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

/* ---------------------------------------------------------
   Presenza — interactive prototype + self-running demo mode
   Built for: HackHers · CodeBuild 1.0 Hackathon 2026
   Demonstrates: Smart Punch-In, 75% Tracker, Teacher↔Student
   Chat, Lecture-Wise Rating Engine, Anti-Proxy Lock
--------------------------------------------------------- */

const CATS = { Excellent: "#1FCE8F", Good: "#3EA8C9", Average: "#F2B705", Poor: "#EF476F" };

function categoryFor(pct) {
  if (pct >= 85) return "Excellent";
  if (pct >= 75) return "Good";
  if (pct >= 60) return "Average";
  return "Poor";
}

const INITIAL_SUBJECTS = [
  { id: "thermo", name: "Thermodynamics", teacher: "Prof. Rao", attended: 22, planned: 31, room: "204" },
  { id: "ds", name: "Data Structures", teacher: "Prof. Iyer", attended: 34, planned: 38, room: "Lab 3" },
  { id: "circuits", name: "Circuit Theory", teacher: "Prof. Malhotra", attended: 19, planned: 29, room: "112" },
  { id: "comm", name: "Communication Skills", teacher: "Prof. Sen", attended: 24, planned: 26, room: "Seminar Hall" },
];

const ROSTER = [
  { name: "Aanya Kapoor", pct: 91 }, { name: "Rohan Verma", pct: 88 },
  { name: "Ishita Nair", pct: 79 }, { name: "Karan Mehta", pct: 76 },
  { name: "Sana Sheikh", pct: 68 }, { name: "Devansh Rao", pct: 63 },
  { name: "Priya Das", pct: 58 }, { name: "Aditya Bose", pct: 52 },
  { name: "Meera Pillai", pct: 96 }, { name: "Yusuf Khan", pct: 82 },
  { name: "Tanvi Joshi", pct: 71 }, { name: "Farhan Ali", pct: 44 },
].map((s) => ({ ...s, category: categoryFor(s.pct) }));

const PUNCH_NAMES = ["Aanya K.", "Rohan V.", "Sana S.", "Devansh R.", "Meera P.", "Yusuf K.", "Tanvi J.", "Farhan A."];

const INITIAL_STUDENT_CHAT = [
  { id: 1, from: "teacher", text: "Reminder: Thermodynamics unit test moved to Friday.", time: "9:02 AM" },
  { id: 2, from: "system", text: "You are 4 lectures from Good in Thermodynamics.", time: "9:04 AM" },
];
const INITIAL_TEACHER_CHAT = [
  { id: 1, from: "teacher", text: "Reminder: Thermodynamics unit test moved to Friday.", time: "9:02 AM" },
];

/* ================= ROOT ================= */

export default function Presenza() {
  const [role, setRole] = useState("student");
  const [studentTab, setStudentTab] = useState("home");
  const [teacherTab, setTeacherTab] = useState("session");
  const [studentChat, setStudentChat] = useState(INITIAL_STUDENT_CHAT);
  const [teacherChat, setTeacherChat] = useState(INITIAL_TEACHER_CHAT);
  const [attendance, setAttendance] = useState(INITIAL_SUBJECTS);
  const [ratingSubjects, setRatingSubjects] = useState(INITIAL_SUBJECTS);
  const [punchStep, setPunchStep] = useState("idle");
  const [sessionLive, setSessionLive] = useState(false);
  const [sessionFeed, setSessionFeed] = useState([]);

  const [demoRunning, setDemoRunning] = useState(false);
  const [caption, setCaption] = useState("");
  const [progress, setProgress] = useState(0);

  const timers = useRef([]);
  const progressTimer = useRef(null);

  const schedule = (fn, delay) => {
    const id = setTimeout(fn, delay);
    timers.current.push(id);
    return id;
  };
  const clearAllTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
    if (progressTimer.current) clearInterval(progressTimer.current);
  };

  const startPunch = () => {
    setPunchStep("device");
    schedule(() => setPunchStep("gps"), 800);
    schedule(() => setPunchStep("window"), 1650);
    schedule(() => {
      setPunchStep("done");
      setAttendance((prev) => prev.map((s, i) => (i === 0 ? { ...s, attended: s.attended + 1 } : s)));
    }, 2450);
  };
  const resetPunch = () => setPunchStep("idle");

  const sendStudentMsg = (text) =>
    setStudentChat((c) => [...c, { id: c.length + 1, from: "student", text, time: "now" }]);
  const sendTeacherMsg = (text) =>
    setTeacherChat((c) => [...c, { id: c.length + 1, from: "teacher", text, time: "now" }]);

  const simulatePunchDemo = () => {
    const name = PUNCH_NAMES[Math.floor(Math.random() * PUNCH_NAMES.length)];
    const t = new Date();
    const time = `${t.getHours() % 12 || 12}:${String(t.getMinutes()).padStart(2, "0")}`;
    setSessionFeed((f) => [{ name, time, id: f.length + Math.random() }, ...f].slice(0, 6));
  };

  /* ---------- demo script ---------- */
  const DEMO = [
    { delay: 0, caption: "Proxy attendance. No real-time visibility. Class updates lost in a WhatsApp group.", action: () => { setRole("student"); setStudentTab("home"); resetPunch(); setSessionLive(false); setSessionFeed([]); } },
    { delay: 7000, caption: "Presenza fixes it — one portal, verified attendance, direct communication." },
    { delay: 14000, caption: "Here's a live Thermodynamics session. Watch what happens on punch-in." },
    { delay: 19000, caption: "One tap runs three checks — device binding, live GPS, session window — before marking anyone present.", action: () => startPunch() },
    { delay: 30000, caption: "That's what makes proxy attendance impossible." },
    { delay: 37000, caption: "Next, the 75% tracker.", action: () => setStudentTab("tracker") },
    { delay: 41000, caption: "Every student sees exactly where they stand, subject by subject." },
    { delay: 48000, caption: "Presenza tells them precisely how many lectures they need — before it's a crisis." },
    { delay: 57000, caption: "When plans change, there's a direct line to the teacher — no more forwarded messages.", action: () => setStudentTab("chat") },
    { delay: 63000, caption: "Students can message their teacher directly, too.", action: () => sendStudentMsg("Got it, thank you Professor!") },
    { delay: 72000, caption: "Now, the teacher side.", action: () => { setRole("teacher"); setTeacherTab("rating"); } },
    { delay: 78000, caption: "Teachers set lectures planned per topic — thresholds recalculate instantly.", action: () => setRatingSubjects((prev) => prev.map((s, i) => (i === 0 ? { ...s, planned: 34 } : s))) },
    { delay: 88000, caption: "Starting a live session — geofenced to the classroom, locked to each device.", action: () => { setTeacherTab("session"); setSessionLive(true); } },
    { delay: 95000, caption: "Punch-ins arrive live, geo-verified.", action: () => simulatePunchDemo() },
    { delay: 98500, action: () => simulatePunchDemo() },
    { delay: 102000, action: () => simulatePunchDemo() },
    { delay: 107000, caption: "At a glance: the whole class's attendance health, with at-risk students flagged automatically.", action: () => setTeacherTab("roster") },
    { delay: 120000, caption: "One portal. Verified attendance. Direct communication. Zero middlemen. That's Presenza." },
    { delay: 132000, caption: "" },
  ];
  const TOTAL = 134000;

  const runDemo = () => {
    clearAllTimers();
    setDemoRunning(true);
    setProgress(0);
    const start = Date.now();
    progressTimer.current = setInterval(() => {
      setProgress(Math.min(100, ((Date.now() - start) / TOTAL) * 100));
    }, 200);
    DEMO.forEach((step) => {
      schedule(() => {
        if (step.caption !== undefined) setCaption(step.caption);
        step.action?.();
      }, step.delay);
    });
    schedule(() => {
      setDemoRunning(false);
      setProgress(0);
      if (progressTimer.current) clearInterval(progressTimer.current);
    }, TOTAL);
  };
  const stopDemo = () => {
    clearAllTimers();
    setDemoRunning(false);
    setCaption("");
    setProgress(0);
  };

  useEffect(() => clearAllTimers, []);

  return (
    <div className="stage">
      <style>{CSS}</style>
      <div className="stage-bg"><div className="orb orb-a" /><div className="orb orb-b" /></div>

      <div className="toolbar">
        <div className="brand">
          <span className="brand-mark">P</span>
          <div>
            <div className="brand-name">Presenza</div>
            <div className="brand-sub">interactive prototype</div>
          </div>
        </div>
        <div className="toolbar-right">
          <div className="role-switch">
            <button className={role === "student" ? "role-btn active" : "role-btn"} onClick={() => !demoRunning && setRole("student")}>
              <GraduationCap size={15} /> Student
            </button>
            <button className={role === "teacher" ? "role-btn active" : "role-btn"} onClick={() => !demoRunning && setRole("teacher")}>
              <Building2 size={15} /> Teacher
            </button>
          </div>
          <button className={demoRunning ? "demo-btn stop" : "demo-btn"} onClick={demoRunning ? stopDemo : runDemo}>
            {demoRunning ? <><Square size={14} /> Stop demo</> : <><Play size={14} /> Play full demo</>}
          </button>
        </div>
      </div>

      {demoRunning && <div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>}

      <div className="phone-wrap">
        <div className="phone">
          <div className="notch" />
          <div className="statusbar">
            <span>9:41</span>
            <span className="statusbar-icons"><Radio size={12} /> <Lock size={11} /> <Smartphone size={12} /></span>
          </div>
          <div className="screen">
            {role === "student" ? (
              <StudentApp
                tab={studentTab} setTab={demoRunning ? () => {} : setStudentTab}
                chat={studentChat} onSend={sendStudentMsg}
                attendance={attendance}
                punchStep={punchStep} onPunch={startPunch} onResetPunch={resetPunch}
              />
            ) : (
              <TeacherApp
                tab={teacherTab} setTab={demoRunning ? () => {} : setTeacherTab}
                chat={teacherChat} onSend={sendTeacherMsg}
                subjects={ratingSubjects} setSubjects={setRatingSubjects}
                sessionLive={sessionLive} setSessionLive={setSessionLive}
                sessionFeed={sessionFeed} onSimulatePunch={simulatePunchDemo}
              />
            )}
          </div>
        </div>

        {caption && demoRunning ? (
          <div className="caption-bar">{caption}</div>
        ) : (
          <div className="phone-caption">
            {demoRunning ? "" : "Tap around manually, or hit “Play full demo” and screen-record hands-free"}
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= STUDENT APP ================= */

function StudentApp({ tab, setTab, chat, onSend, attendance, punchStep, onPunch, onResetPunch }) {
  const unread = chat.some((m) => m.from !== "student") ? 1 : 0;
  const overallAttended = attendance.reduce((a, s) => a + s.attended, 0);
  const overallPlanned = attendance.reduce((a, s) => a + s.planned, 0);
  const overallPct = Math.round((overallAttended / overallPlanned) * 100);
  const overallCat = categoryFor(overallPct);

  return (
    <>
      <div className="app-body">
        {tab === "home" && <PunchInScreen subject={attendance[0]} step={punchStep} onPunch={onPunch} onReset={onResetPunch} />}
        {tab === "tracker" && <TrackerScreen overallPct={overallPct} overallCat={overallCat} subjects={attendance} />}
        {tab === "chat" && <ChatScreen chat={chat} onSend={onSend} title="Prof. Rao · Thermodynamics" />}
      </div>
      <TabBar tab={tab} setTab={setTab} items={[
        { key: "home", label: "Punch In", icon: CheckCircle2 },
        { key: "tracker", label: "Tracker", icon: TrendingUp },
        { key: "chat", label: "Chat", icon: MessageCircle, badge: unread },
      ]} />
    </>
  );
}

function PunchInScreen({ subject, step, onPunch, onReset }) {
  const checks = [
    { key: "device", label: "Device binding verified", icon: Smartphone },
    { key: "gps", label: "GPS inside Room 204 (12m)", icon: MapPin },
    { key: "window", label: "Live session window open", icon: Clock },
  ];
  const order = ["device", "gps", "window", "done"];
  const isPast = (k) => order.indexOf(step) > order.indexOf(k) || step === "done";
  const isActive = (k) => step === k;

  return (
    <div className="screen-pad">
      <div className="eyebrow">Ongoing session</div>
      <h2 className="h2">{subject.name}</h2>
      <div className="meta-row"><span>{subject.teacher}</span><span className="dot" /><span>Room {subject.room}</span><span className="dot" /><span>ends in 34 min</span></div>

      <div className="punch-card">
        {step === "idle" && (
          <>
            <button className="punch-btn" onClick={onPunch}><CheckCircle2 size={22} /> Punch in now</button>
            <p className="hint">One tap logs you against this live session — verified in three steps.</p>
          </>
        )}
        {step !== "idle" && step !== "done" && (
          <div className="check-list">
            {checks.map((c) => (
              <div key={c.key} className={"check-row" + (isPast(c.key) ? " check-done" : isActive(c.key) ? " check-active" : "")}>
                <span className="check-icon">{isPast(c.key) ? <CheckCircle2 size={18} /> : <c.icon size={18} />}</span>
                {c.label}
                {isActive(c.key) && <span className="spinner" />}
              </div>
            ))}
          </div>
        )}
        {step === "done" && (
          <div className="success-block">
            <div className="success-ring"><CheckCircle2 size={30} /></div>
            <div className="success-title">You're marked present</div>
            <div className="success-sub">Thermodynamics · logged at 9:41 AM · geo-verified</div>
            <button className="link-btn" onClick={onReset}>Reset demo</button>
          </div>
        )}
      </div>
      <div className="proof-strip"><ShieldCheck size={14} /> Single-device lock active · tamper-proof record</div>
    </div>
  );
}

function Ring({ pct, color, size = 128 }) {
  const stroke = 12;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  return (
    <svg width={size} height={size} className="ring">
      <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.12)" strokeWidth={stroke} fill="none" />
      <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none"
        strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: "stroke-dashoffset .6s ease" }} />
      <text x="50%" y="46%" textAnchor="middle" className="ring-pct">{pct}%</text>
      <text x="50%" y="63%" textAnchor="middle" className="ring-label">overall</text>
    </svg>
  );
}

function TrackerScreen({ overallPct, overallCat, subjects }) {
  return (
    <div className="screen-pad scroll">
      <div className="eyebrow">75% tracker</div>
      <h2 className="h2">Where you stand</h2>
      <div className="ring-card">
        <Ring pct={overallPct} color={CATS[overallCat]} />
        <div className="ring-side">
          <span className="cat-pill" style={{ background: CATS[overallCat] }}>{overallCat}</span>
          <p className="ring-note">{overallPct >= 75 ? "You're clear of the 75% exam-eligibility line." : "Attend more classes to clear the 75% line before it's too late."}</p>
        </div>
      </div>
      <div className="sub-list">
        {subjects.map((s) => {
          const pct = Math.round((s.attended / s.planned) * 100);
          const cat = categoryFor(pct);
          const nextCatAt = cat === "Poor" ? 60 : cat === "Average" ? 75 : cat === "Good" ? 85 : null;
          const needed = nextCatAt ? Math.max(0, Math.ceil((nextCatAt * s.planned) / 100) - s.attended) : 0;
          return (
            <div className="sub-row" key={s.id}>
              <div className="sub-row-top"><span className="sub-name">{s.name}</span><span className="cat-pill sm" style={{ background: CATS[cat] }}>{cat}</span></div>
              <div className="bar-track"><div className="bar-fill" style={{ width: `${pct}%`, background: CATS[cat] }} /></div>
              <div className="sub-row-bottom">
                <span>{s.attended}/{s.planned} lectures · {pct}%</span>
                {needed > 0 && <span className="need-note">Attend {needed} more for {nextCatAt >= 85 ? "Excellent" : nextCatAt >= 75 ? "Good" : "Average"}</span>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ChatScreen({ chat, onSend, title }) {
  const [text, setText] = useState("");
  const endRef = useRef(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [chat]);
  return (
    <div className="chat-wrap">
      <div className="chat-header">
        <div className="avatar">PR</div>
        <div><div className="chat-title">{title}</div><div className="chat-sub">Direct line · no CR needed</div></div>
      </div>
      <div className="chat-body">
        {chat.map((m) => (
          <div key={m.id} className={m.from === "student" || m.from === "teacher-self" ? "bubble bubble-me" : m.from === "system" ? "bubble bubble-sys" : "bubble bubble-them"}>
            {m.from === "system" && <Bell size={12} className="sys-icon" />}
            {m.text}<span className="bubble-time">{m.time}</span>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <form className="chat-input" onSubmit={(e) => { e.preventDefault(); if (!text.trim()) return; onSend(text.trim()); setText(""); }}>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Message your teacher…" />
        <button type="submit"><Send size={16} /></button>
      </form>
    </div>
  );
}

function TabBar({ tab, setTab, items }) {
  return (
    <div className="tabbar">
      {items.map((it) => (
        <button key={it.key} className={tab === it.key ? "tab active" : "tab"} onClick={() => setTab(it.key)}>
          <span className="tab-icon-wrap"><it.icon size={19} />{!!it.badge && <span className="tab-badge" />}</span>
          {it.label}
        </button>
      ))}
    </div>
  );
}

/* ================= TEACHER APP ================= */

function TeacherApp({ tab, setTab, chat, onSend, subjects, setSubjects, sessionLive, setSessionLive, sessionFeed, onSimulatePunch }) {
  return (
    <>
      <div className="app-body">
        {tab === "session" && <SessionScreen subject={subjects[0]} live={sessionLive} setLive={setSessionLive} feed={sessionFeed} onSimulate={onSimulatePunch} />}
        {tab === "roster" && <RosterScreen />}
        {tab === "rating" && <RatingScreen subjects={subjects} setSubjects={setSubjects} />}
        {tab === "chat" && <ChatScreen chat={chat.map((m) => ({ ...m, from: m.from === "teacher" ? "teacher-self" : m.from }))} onSend={onSend} title="Batch CS-3B · 42 students" />}
      </div>
      <TabBar tab={tab} setTab={setTab} items={[
        { key: "session", label: "Session", icon: Radio },
        { key: "roster", label: "Roster", icon: Users },
        { key: "rating", label: "Ratings", icon: BookOpen },
        { key: "chat", label: "Chat", icon: MessageCircle },
      ]} />
    </>
  );
}

function SessionScreen({ subject, live, setLive, feed, onSimulate }) {
  return (
    <div className="screen-pad scroll">
      <div className="eyebrow">Live session</div>
      <h2 className="h2">{subject.name}</h2>
      <div className="meta-row"><span>Room {subject.room}</span><span className="dot" /><span>{live ? "Session open" : "Not started"}</span></div>

      {!live ? (
        <button className="punch-btn" onClick={() => setLive(true)}><Radio size={20} /> Start session</button>
      ) : (
        <>
          <div className="geo-card">
            <div className="geo-row"><MapPin size={15} /> Geofence: 50m radius, Room 204</div>
            <div className="geo-row"><Smartphone size={15} /> Device binding: enforced</div>
            <div className="geo-row"><Clock size={15} /> Window closes in 34 min</div>
          </div>
          <button className="secondary-btn" onClick={onSimulate}>Simulate a student punch-in</button>
          <div className="feed-title">Live punch-ins ({feed.length})</div>
          <div className="feed-list">
            {feed.length === 0 && <div className="hint">Tap the button above — punches will appear here in real time.</div>}
            {feed.map((f) => (
              <div className="feed-row" key={f.id}><span className="feed-dot" />{f.name}<span className="feed-time">{f.time}</span><CheckCircle2 size={14} color={CATS.Excellent} /></div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function RosterScreen() {
  const counts = ["Excellent", "Good", "Average", "Poor"].map((cat) => ({ name: cat, value: ROSTER.filter((s) => s.category === cat).length, color: CATS[cat] }));
  const atRisk = ROSTER.filter((s) => s.category === "Poor").sort((a, b) => a.pct - b.pct);
  return (
    <div className="screen-pad scroll">
      <div className="eyebrow">Class snapshot</div>
      <h2 className="h2">Batch CS-3B</h2>
      <div className="pie-card">
        <div style={{ width: 120, height: 120 }}>
          <ResponsiveContainer>
            <PieChart>
              <Pie data={counts} dataKey="value" nameKey="name" innerRadius={30} outerRadius={55} paddingAngle={2}>
                {counts.map((c, i) => <Cell key={i} fill={c.color} />)}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="pie-legend">
          {counts.map((c) => <div className="legend-row" key={c.name}><span className="legend-dot" style={{ background: c.color }} />{c.name} <b>{c.value}</b></div>)}
        </div>
      </div>
      <div className="feed-title"><AlertTriangle size={13} color={CATS.Poor} /> Needs attention ({atRisk.length})</div>
      <div className="roster-list">
        {atRisk.map((s) => <div className="roster-row" key={s.name}><span>{s.name}</span><span className="cat-pill sm" style={{ background: CATS.Poor }}>{s.pct}%</span></div>)}
      </div>
    </div>
  );
}

function RatingScreen({ subjects, setSubjects }) {
  const update = (id, planned) => setSubjects((prev) => prev.map((s) => (s.id === id ? { ...s, planned: Math.max(1, planned) } : s)));
  return (
    <div className="screen-pad scroll">
      <div className="eyebrow">Rating engine setup</div>
      <h2 className="h2">Lectures per topic</h2>
      <p className="hint">Set the planned lecture count — thresholds recalculate instantly for every student.</p>
      {subjects.map((s) => {
        const ex = Math.ceil(0.85 * s.planned), good = Math.ceil(0.75 * s.planned), avg = Math.ceil(0.6 * s.planned);
        return (
          <div className="rating-card" key={s.id}>
            <div className="rating-top">
              <span className="sub-name">{s.name}</span>
              <input type="number" min={1} value={s.planned} onChange={(e) => update(s.id, parseInt(e.target.value || "1", 10))} />
            </div>
            <div className="thresh-row"><span className="cat-pill sm" style={{ background: CATS.Excellent }}>Excellent</span> ≥ {ex} lectures</div>
            <div className="thresh-row"><span className="cat-pill sm" style={{ background: CATS.Good }}>Good</span> ≥ {good} lectures</div>
            <div className="thresh-row"><span className="cat-pill sm" style={{ background: CATS.Average }}>Average</span> ≥ {avg} lectures</div>
          </div>
        );
      })}
    </div>
  );
}

/* ================= STYLES ================= */

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;500;600;700&display=swap');

.stage { position: relative; min-height: 800px; padding: 28px 16px 40px; font-family: 'Inter', sans-serif; color: #EAF4F1; overflow: hidden; }
.stage-bg { position: absolute; inset: 0; background: #0A2E36; z-index: 0; }
.orb { position: absolute; border-radius: 50%; filter: blur(2px); opacity: 0.5; }
.orb-a { width: 340px; height: 340px; background: radial-gradient(circle, #123F49 0%, transparent 70%); top: -140px; left: -120px; }
.orb-b { width: 380px; height: 380px; background: radial-gradient(circle, #123F49 0%, transparent 70%); bottom: -160px; right: -140px; }

.toolbar, .phone-wrap { position: relative; z-index: 1; }
.toolbar { display: flex; align-items: center; justify-content: space-between; max-width: 480px; margin: 0 auto 14px; flex-wrap: wrap; gap: 12px; }
.brand { display: flex; align-items: center; gap: 10px; }
.brand-mark { width: 34px; height: 34px; border-radius: 9px; background: #1FCE8F; color: #0A2E36; display: flex; align-items: center; justify-content: center; font-family: 'Fraunces', serif; font-weight: 700; font-size: 18px; }
.brand-name { font-family: 'Fraunces', serif; font-weight: 700; font-size: 17px; }
.brand-sub { font-size: 11px; color: #8FB3AE; }
.toolbar-right { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.role-switch { display: flex; background: rgba(255,255,255,0.06); border-radius: 999px; padding: 4px; gap: 2px; }
.role-btn { display: flex; align-items: center; gap: 6px; border: none; background: transparent; color: #C6DAD6; font-size: 12.5px; font-weight: 600; padding: 8px 14px; border-radius: 999px; cursor: pointer; font-family: 'Inter', sans-serif; transition: all .2s; }
.role-btn.active { background: #1FCE8F; color: #0A2E36; }
.demo-btn { display: flex; align-items: center; gap: 7px; background: #F2B705; color: #06231C; border: none; padding: 9px 16px; border-radius: 999px; font-size: 12.5px; font-weight: 700; cursor: pointer; font-family: 'Inter', sans-serif; }
.demo-btn.stop { background: #EF476F; color: #fff; }

.progress-track { max-width: 375px; margin: 0 auto 10px; height: 4px; background: rgba(255,255,255,0.1); border-radius: 4px; overflow: hidden; position: relative; z-index: 1; }
.progress-fill { height: 100%; background: #1FCE8F; transition: width .2s linear; }

.phone-wrap { display: flex; flex-direction: column; align-items: center; }
.phone { width: 375px; max-width: 92vw; height: 720px; background: linear-gradient(180deg,#0E3A44,#0A2E36); border-radius: 42px; border: 6px solid #06232A; box-shadow: 0 30px 70px rgba(0,0,0,0.45); position: relative; overflow: hidden; display: flex; flex-direction: column; }
.notch { position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 140px; height: 22px; background: #06232A; border-radius: 0 0 14px 14px; z-index: 5; }
.statusbar { display: flex; justify-content: space-between; padding: 14px 24px 4px; font-size: 12px; font-weight: 600; color: #EAF4F1; }
.statusbar-icons { display: flex; gap: 6px; opacity: 0.8; }
.screen { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
.phone-caption { margin-top: 16px; font-size: 12px; color: #8FB3AE; text-align: center; max-width: 320px; min-height: 16px; }
.caption-bar { margin-top: 16px; max-width: 375px; background: rgba(6,35,42,0.85); border: 1px solid rgba(31,206,143,0.3); border-radius: 12px; padding: 12px 18px; font-size: 13.5px; line-height: 1.5; text-align: center; color: #EAF4F1; min-height: 20px; }

.app-body { flex: 1; overflow-y: auto; }
.screen-pad { padding: 20px 22px 12px; }
.scroll { overflow-y: auto; }
.eyebrow { font-size: 11px; letter-spacing: 0.04em; color: #63D9A6; font-weight: 600; margin-bottom: 6px; }
.h2 { font-family: 'Fraunces', serif; font-size: 24px; font-weight: 700; margin: 0 0 8px; line-height: 1.15; }
.meta-row { display: flex; align-items: center; gap: 8px; font-size: 12.5px; color: #A9C7C2; margin-bottom: 18px; }
.dot { width: 3px; height: 3px; border-radius: 50%; background: #5C7C77; }
.hint { font-size: 12.5px; color: #93B4AF; line-height: 1.5; margin-top: 10px; }

.punch-card { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 18px; padding: 22px; text-align: center; }
.punch-btn { width: 100%; display: flex; align-items: center; justify-content: center; gap: 10px; background: #1FCE8F; color: #06231C; border: none; padding: 16px; border-radius: 14px; font-size: 15px; font-weight: 700; cursor: pointer; font-family: 'Inter', sans-serif; transition: transform .15s; }
.punch-btn:hover { transform: translateY(-1px); }
.secondary-btn { width: 100%; background: rgba(255,255,255,0.08); color: #EAF4F1; border: 1px solid rgba(255,255,255,0.14); padding: 12px; border-radius: 12px; font-size: 13px; font-weight: 600; cursor: pointer; margin: 14px 0; font-family: 'Inter', sans-serif; }

.check-list { display: flex; flex-direction: column; gap: 12px; text-align: left; }
.check-row { display: flex; align-items: center; gap: 10px; font-size: 13px; color: #7F9F9A; padding: 8px 10px; border-radius: 10px; position: relative; }
.check-row.check-active { color: #EAF4F1; background: rgba(255,255,255,0.05); }
.check-row.check-done { color: #1FCE8F; }
.check-icon { display: flex; }
.spinner { margin-left: auto; width: 12px; height: 12px; border: 2px solid rgba(255,255,255,0.2); border-top-color: #1FCE8F; border-radius: 50%; animation: spin .7s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.success-block { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 8px 0; }
.success-ring { width: 56px; height: 56px; border-radius: 50%; background: rgba(31,206,143,0.15); color: #1FCE8F; display: flex; align-items: center; justify-content: center; margin-bottom: 6px; }
.success-title { font-family: 'Fraunces', serif; font-weight: 700; font-size: 17px; }
.success-sub { font-size: 12px; color: #93B4AF; }
.link-btn { margin-top: 10px; background: none; border: none; color: #63D9A6; font-size: 12.5px; font-weight: 600; cursor: pointer; text-decoration: underline; font-family: 'Inter', sans-serif; }

.proof-strip { display: flex; align-items: center; gap: 7px; justify-content: center; font-size: 11px; color: #7F9F9A; margin-top: 16px; }

.ring { display: block; }
.ring-pct { fill: #EAF4F1; font-family: 'Fraunces', serif; font-weight: 700; font-size: 22px; }
.ring-label { fill: #8FB3AE; font-size: 10px; font-family: 'Inter', sans-serif; }
.ring-card { display: flex; align-items: center; gap: 18px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); border-radius: 18px; padding: 18px; margin-bottom: 18px; }
.ring-side { flex: 1; }
.ring-note { font-size: 12px; color: #A9C7C2; line-height: 1.5; margin-top: 8px; }
.cat-pill { display: inline-block; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; color: #06231C; }
.cat-pill.sm { padding: 3px 8px; font-size: 10px; }

.sub-list { display: flex; flex-direction: column; gap: 14px; padding-bottom: 10px; }
.sub-row { background: rgba(255,255,255,0.04); border-radius: 14px; padding: 14px; }
.sub-row-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.sub-name { font-size: 13.5px; font-weight: 600; }
.bar-track { height: 6px; border-radius: 4px; background: rgba(255,255,255,0.1); overflow: hidden; }
.bar-fill { height: 100%; border-radius: 4px; }
.sub-row-bottom { display: flex; justify-content: space-between; font-size: 11px; color: #93B4AF; margin-top: 8px; }
.need-note { color: #F2B705; font-weight: 600; }

.chat-wrap { display: flex; flex-direction: column; height: 100%; }
.chat-header { display: flex; align-items: center; gap: 10px; padding: 16px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); }
.avatar { width: 34px; height: 34px; border-radius: 50%; background: #1FCE8F; color: #06231C; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 12px; }
.chat-title { font-size: 13.5px; font-weight: 700; }
.chat-sub { font-size: 11px; color: #8FB3AE; }
.chat-body { flex: 1; overflow-y: auto; padding: 16px 18px; display: flex; flex-direction: column; gap: 10px; }
.bubble { max-width: 78%; padding: 9px 13px; border-radius: 14px; font-size: 12.5px; line-height: 1.4; position: relative; }
.bubble-time { display: block; font-size: 9.5px; opacity: 0.6; margin-top: 3px; }
.bubble-them { align-self: flex-start; background: rgba(255,255,255,0.08); border-bottom-left-radius: 4px; }
.bubble-me { align-self: flex-end; background: #1FCE8F; color: #06231C; border-bottom-right-radius: 4px; }
.bubble-sys { align-self: center; background: rgba(242,183,5,0.15); color: #F2B705; font-size: 11px; display: flex; align-items: center; gap: 6px; }
.sys-icon { flex-shrink: 0; }
.chat-input { display: flex; gap: 8px; padding: 12px 16px; border-top: 1px solid rgba(255,255,255,0.08); }
.chat-input input { flex: 1; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); border-radius: 999px; padding: 10px 14px; color: #EAF4F1; font-size: 12.5px; font-family: 'Inter', sans-serif; outline: none; }
.chat-input button { width: 36px; height: 36px; border-radius: 50%; background: #1FCE8F; color: #06231C; border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; }

.tabbar { display: flex; border-top: 1px solid rgba(255,255,255,0.08); background: rgba(6,35,42,0.6); padding: 8px 6px 12px; }
.tab { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px; background: none; border: none; color: #6E8F8A; font-size: 10px; font-weight: 600; cursor: pointer; padding: 6px 2px; font-family: 'Inter', sans-serif; }
.tab.active { color: #1FCE8F; }
.tab-icon-wrap { position: relative; }
.tab-badge { position: absolute; top: -2px; right: -4px; width: 7px; height: 7px; border-radius: 50%; background: #EF476F; }

.geo-card { background: rgba(255,255,255,0.05); border-radius: 14px; padding: 14px; display: flex; flex-direction: column; gap: 9px; margin-bottom: 6px; }
.geo-row { display: flex; align-items: center; gap: 9px; font-size: 12px; color: #C6DAD6; }
.feed-title { display: flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 700; color: #93B4AF; margin: 16px 0 10px; text-transform: uppercase; letter-spacing: 0.03em; }
.feed-list { display: flex; flex-direction: column; gap: 8px; }
.feed-row { display: flex; align-items: center; gap: 9px; font-size: 12.5px; background: rgba(255,255,255,0.04); padding: 9px 12px; border-radius: 10px; }
.feed-dot { width: 6px; height: 6px; border-radius: 50%; background: #1FCE8F; }
.feed-time { margin-left: auto; color: #7F9F9A; font-size: 11px; }

.pie-card { display: flex; align-items: center; gap: 18px; background: rgba(255,255,255,0.05); border-radius: 16px; padding: 16px; margin-bottom: 8px; }
.pie-legend { display: flex; flex-direction: column; gap: 8px; font-size: 12px; }
.legend-row { display: flex; align-items: center; gap: 8px; color: #C6DAD6; }
.legend-row b { margin-left: auto; color: #EAF4F1; }
.legend-dot { width: 9px; height: 9px; border-radius: 3px; }
.roster-list { display: flex; flex-direction: column; gap: 8px; padding-bottom: 12px; }
.roster-row { display: flex; justify-content: space-between; align-items: center; background: rgba(239,71,111,0.08); padding: 10px 13px; border-radius: 10px; font-size: 12.5px; }

.rating-card { background: rgba(255,255,255,0.05); border-radius: 14px; padding: 14px 16px; margin-bottom: 12px; }
.rating-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.rating-top input { width: 60px; background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.14); border-radius: 8px; padding: 6px 8px; color: #EAF4F1; font-size: 12.5px; text-align: center; font-family: 'Inter', sans-serif; }
.thresh-row { display: flex; align-items: center; gap: 8px; font-size: 12px; color: #C6DAD6; padding: 4px 0; }
`;
